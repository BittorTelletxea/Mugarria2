import org.jdesktop.swingx.JXDatePicker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class PictureViewer extends JFrame {
    private JLabel argazkilariaen_label;
    private JComboBox argazkilariak;
    private JLabel data_label;
    private JLabel argazkia;
    private JXDatePicker data;
    private JList lista;
    private ImageIcon Icon;

    public PictureViewer(){

        this.setLayout(new GridLayout(2,2,15,25));
        this.setPreferredSize(new Dimension(1100,750));
        this.argazkilariaen_label = new JLabel("Photographer: ");
        this.data_label = new JLabel("Photos after");
        this.argazkilariak = new JComboBox<>(loadCombo());
        argazkilariak.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lista();
            }
        });


        this.lista = new JList<>();
        this.lista.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    String nameImage = (String) lista.getSelectedValue();
                    Path(nameImage);

                }
            }
        });

        this.data = new JXDatePicker();
        this.argazkia = new JLabel();
        JPanel GoraEzker = new JPanel();
        GoraEzker.add(this.argazkilariaen_label);
        GoraEzker.add(this.argazkilariak);

        JPanel GoraEskuin = new JPanel();
        GoraEskuin.add(data_label);
        GoraEskuin.add(data);

        this.add(GoraEzker);

        this.add(GoraEskuin);

        this.add(this.lista);

        this.add(this.argazkia);


        setTitle("Grid Frame");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        new PictureViewer();
    }

    public String[] loadCombo() {
        DBkonexioa connection = null;
        List<String> names = new ArrayList<>();
        try {
            connection = new DBkonexioa();
            ResultSet select = connection.select("select name from Photographers");
            while (select.next()) {
                names.add(select.getString("name"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (connection != null) {
                connection.cerrar();
            }
        }
        return names.toArray(new String[0]);
    }
    public void lista() {
        String selectedPhotographer = (String) argazkilariak.getSelectedItem();
        if (selectedPhotographer == null) {
            return;
        }
        DBkonexioa connection = null;
        DefaultListModel<String> model = new DefaultListModel<>();
        try {
            connection = new DBkonexioa();
            ResultSet selectId = connection.select("select PhotographerId from Photographers where name ='" + selectedPhotographer + "'");
            String photographerId = null;
            if (selectId.next()) {
                photographerId = selectId.getString("PhotographerId");
            }
            ResultSet select = null;
            if (data.getDate()!=null){
                SimpleDateFormat newdate = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = newdate.format(this.data.getDate());
                select = connection.select("select title from pictures where photographerId='" + photographerId + "' and date >'" + formattedDate + "'");

            }else{
                select = connection.select("select title from pictures where photographerId='" + photographerId + "'");
            }
            while (select.next()) {
                model.addElement(select.getString("title"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (connection != null) {
                connection.cerrar();
            }
        }
        lista.setModel(model);
    }

    public void Argazkia(String path){

        this.Icon = new ImageIcon(path);
        Image foto = this.Icon.getImage();
        Image newfoto = foto.getScaledInstance(250,250,Image.SCALE_SMOOTH);
        ImageIcon newlogo = new ImageIcon(newfoto);
        this.argazkia.setIcon(newlogo);
        DBkonexioa connection = null;
        try {
            connection = new DBkonexioa();
            connection.update("update pictures set visits=visits+1 where file ='" + path + "'");
        }catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (connection != null) {
                connection.cerrar();
            }
        }
    }

    public void Path(String namePicture){
        DBkonexioa connection = null;
        String path = null;
        try {
            connection = new DBkonexioa();
            ResultSet selectId = connection.select("select File from Pictures where title ='" + namePicture + "'");
            if (selectId.next()) {
                path = selectId.getString("File");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            Argazkia(path);
            if (connection != null) {
                connection.cerrar();
            }
        }
    }


}